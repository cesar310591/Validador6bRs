package com.rent.rentame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;

import java.awt.font.TextAttribute;

public class MainActivity extends AppCompatActivity {
private TextView registro;
private ImageView ingresar;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        registro = findViewById(R.id.tvRegistro);
        ingresar = findViewById(R.id.imgIngresar);


registro.setOnClickListener(new View.OnClickListener(){
    @Override
    public void onClick(View v) {
        Intent intent = new Intent(MainActivity.this, registro.class);
        // intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        // intent.putExtra("ini", "si");
       // intent.putExtra("rfc", rfcc);
        startActivity(intent);
    }
});



ingresar.setOnClickListener(new View.OnClickListener(){
    @Override
    public void onClick(View v) {
        Intent intent = new Intent(MainActivity.this, principal.class);
        // intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        // intent.putExtra("ini", "si");
        // intent.putExtra("rfc", rfcc);
        startActivity(intent);
    }
});

    }
}
